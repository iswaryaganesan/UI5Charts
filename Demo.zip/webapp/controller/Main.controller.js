sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	var PieController = Controller.extend("Demo.controller.Main", {
		onInit: function() {
		var chartName = "Line";//Change chartName according to the Chart page used in Main.view.xml
		var oVizFrame = this.chooseChart(chartName);
        //3. Create Viz dataset to feed to the data to the graph
		var oDataset = new sap.viz.ui5.data.FlattenedDataset({
			dimensions : [{				
			    name : 'BookName',//to display
				value : "{BookName}"},
				{
				name:'Week1',
				value:"{Week}"
				}],//mapping to JSON model property
			               
			measures : [{
				name : 'WoWFactor',
				value : "{WoWFactor}"}],
			             
			data : {
				path : "/Books"
			}
		});					
		oVizFrame.setDataset(oDataset);
		oVizFrame.setModel(this.loadData());
		this.loadChart(chartName,oVizFrame);
		},//onInit End
		loadChart : function(chartName,oVizFrame){
		if(chartName === "Pie"){
			this.loadPieChart(oVizFrame);
		}
		else if(chartName === "Bar"){
			this.loadBarChart(oVizFrame);
		}
		else if(chartName === "HeatMap"){
			this.loadHeatMap(oVizFrame);
		}
		else if(chartName === "Line"){
			this.loadLineChart(oVizFrame);	
		}
		},
		loadLineChart:function(oVizFrame){
			var feedIds = ["primaryValues","axisLabels","color"];
			var uid1 = feedIds[0];
			var uid2 = feedIds[1];
			var uid3 = feedIds[2];
			var feedSize = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      uid: uid1,
		      type: "Measure",
		      values: ["WoWFactor"]// The measured values,dependant on x
		    });
			var  feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      uid: uid2,
		      type: "Dimension",
		      values: ["BookName"]//Variable or items which are measured this is same as name property of defined dimension
		    });
		   var feedDim2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
		   	  uid: uid3,
		      type: "Dimension",
		      values: ["Week1"]
		   });
		oVizFrame.addFeed(feedSize);
		oVizFrame.addFeed(feedColor);
		oVizFrame.addFeed(feedDim2);
		//Set Viz properties
		oVizFrame.setVizProperties({
			title:{
				visible : true,
				text : "My Inspirational Line"
			},
            plotArea: {
            	colorPalette : d3.scale.category20().range(),
            	drawingEffect: "glossy"
                }
			});		
		},
		loadPieChart:function(oVizFrame){
			var feedIds = ["size","color"];
			var uid1 = feedIds[0];
			var uid2 = feedIds[1];
			var feedSize = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      uid: uid1,
		      type: "Measure",
		      values: ["WoWFactor"]// The measured values,dependant on x
		    });
			var  feedColor = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      uid: uid2,
		      type: "Dimension",
		      values: ["BookName"]//Variable or items which are measured
		    });
		oVizFrame.addFeed(feedSize);
		oVizFrame.addFeed(feedColor);
		//Set Viz properties
		oVizFrame.setVizProperties({
			title:{
				visible : true,
				text : "My Inspirational Pie"
			},
            plotArea: {
            	colorPalette : d3.scale.category20().range(),
            	drawingEffect: "glossy"
                }
			});	
		},
		loadBarChart:function(oVizFrame){
			var feedIds = ["primaryValues","axisLabels"];
			var uid1 = feedIds[0];
			var uid2 = feedIds[1];
			var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      uid: uid1,// feedItem id for measure and dimension vary for various charts (it is predefined)
			      type: "Measure",
			      values: ["WoWFactor"]// The measured values,dependant on x
			    });
			 var  feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      uid: uid2,
			      type: "Dimension",
			      values: ["BookName"]//Variable or items which are measured
			    });
			oVizFrame.addFeed(feedValueAxis);
			oVizFrame.addFeed(feedCategoryAxis);
			oVizFrame.setVizProperties({			
            plotArea: {
            	colorPalette : d3.scale.category20().range()
                },
			title:{
				visible:true,
				text:"Inspirational Factor Bar Chart"
			}
			});		
		},
		loadHeatMap:function(oVizFrame){
			var feedIds = ["color","categoryAxis"];
			var uid1 = feedIds[0];
			var uid2 = feedIds[1];
			var  xAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      uid: uid2,
			      type: "Dimension",
			      values: ["BookName"]//Variable or items which are measured
			    });
			 var yAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
			      uid: uid1,// feedItem id for measure and dimension vary for various charts (it is predefined)
			      type: "Measure",
			      values: ["WoWFactor"]// The measured values,dependant on x
			    });
			oVizFrame.addFeed(xAxis);
			oVizFrame.addFeed(yAxis);
			oVizFrame.setVizProperties({			
			title:{
				visible:true,
				text:"Inspirational Factor HeatMap"
			}
			});		
		},
		loadData:function(){
			 //Data
            /*var data = {
			"Books" : [{
				  "BookName": "You can win",
				  "WoWFactor": 5
				},{
				  "BookName": "The Secret",
				  "WoWFactor": 10
				}, {
				  "BookName": "The Power",
				  "WoWFactor": 15
				}, {
				  "BookName": "The Magic",
				  "WoWFactor": 20
				}, {
				  "BookName": "The Hero",
				  "WoWFactor": 25
				}, {
				  "BookName": "Treasure Yourself",
				  "WoWFactor": 30
				}
			]};*/
			var data = {
			"Books" : [{
				  "BookName": "You can win",
				  "Week":1,
				  "WoWFactor": 5
				},{
				  "BookName": "The Secret",
				  "Week":1,
				  "WoWFactor": 10
				}, {
				  "BookName": "The Power",
				  "Week":1,
				  "WoWFactor": 15
				},
				{
				  "BookName": "You can win",
				  "Week":2,
				  "WoWFactor": 25
				},{
				  "BookName": "The Secret",
				  "Week":2,
				  "WoWFactor": 30
				}, {
				  "BookName": "The Power",
				  "Week":2,
				  "WoWFactor": 35
				}
			]};
            var oModel = new sap.ui.model.json.JSONModel();	
            oModel.setData(data);
            return oModel;
		},
		chooseChart:function(chartName){
			var frameId = "idVizFrame"+chartName;
			var oVizFrame = this.getView().byId(frameId);
			oVizFrame.setVizType(chartName.toLowerCase());
			return oVizFrame;
		}
	});//Controller End
return PieController;
});